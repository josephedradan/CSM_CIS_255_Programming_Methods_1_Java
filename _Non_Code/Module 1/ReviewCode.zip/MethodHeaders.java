import java.awt.Point;

public class MethodHeaders {

	public void printFormulas() {
		
	}
	
	public double calculateArea(int base, int height) {
		if(true) {
			return 0;
		} else {
			return 0;			
		}
	}
	
	public double calculateDistance(int x1, int y1, int x2, int y2) {
		return 0;
	}
	public double calculateDistance(Point point1, Point point2) {
		return 0;
	}
	
	public boolean isRightTriangle(int a, int b, int c) {
		return true;
	}
	
}
