// Masters
// June 2015
// Homework W1M1

// this is the class header- it defines the class
public class JavaPredictionProgram {

	/*
	 * this is a method
	 * this particular method is actually a special one you'll see a lot
	 */
	public static void main(String[] args) {

		// this is a Java statement
		System.out.println("This is a test of the Emergency Broadcast System.");
        System.out.println("This is only a test.");

	} // end of the method

} // end of the class


