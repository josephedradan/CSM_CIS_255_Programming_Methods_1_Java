import java.util.Random;

public class Die {
	
	private int faceValue;
	private Random generator;
	
	// public final static int DEFAULT_INITIAL_FACE_VALUE = 1;
	public final static int MIN_VALUE = 1;
	public final static int MAX_VALUE = 6;

	public Die(int initialFaceValue) {
		faceValue = initialFaceValue;
		generator = new Random();
	}
	
	/*
	public Die() {
		roll();
	}
	*/

	public int getFaceValue() {
		return faceValue;
	}
	
	public void setFaceValue(int newFaceValue) {
		if(newFaceValue >= MIN_VALUE && newFaceValue <= MAX_VALUE) {
			faceValue = newFaceValue;
		} else {
			System.out.println("That is an invalid value.");
		}
	}
	
	public String toString() {
		return "Die Value: " + faceValue;
	}
	
	public int roll() {
		int newValue = generator.nextInt(MAX_VALUE - MIN_VALUE + 1) + MIN_VALUE;
		faceValue = newValue;
		return faceValue;
	}
	
	
	
	
	
	
	
	
	
	
}
