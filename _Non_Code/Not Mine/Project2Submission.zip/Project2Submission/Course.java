
public class Course {

    //Max number of the capacity of a course's waitlist and roster space. Variables set as
    //a constant and is set to private for no access by other means.
    private static final int MAX_CAPACITY_REGISTRY = 30;
    private static final int MAX_CAPACITY_WAITLIST = 30;

    //Variables needed to define a course object.
    private int numSpace, numOfWL, addLimit;
    //Variable needed to count the amount of additions to the course.
    private int addCounter = 0;
    //Variables used as switches to determine if a student is in a class's roster or waitlist.
    private boolean inTheRoster, inTheWaitList;
    //Variable needed to set the course's name.
    private String course;

    //Student arrays for registered list roster and wait list
    private Student[] registerList, waitList;

    //Student arrays that shadow the movement of the roster list and the wait list.
    Student[] registeredShadow;
    Student[] waitListShadow;


    //Class constructor that sets the course name, the size of the class and the size of its wait list.
    public Course(String course, int numSpace, int numOfWL) {

        this.course = course;

        if( numSpace <= MAX_CAPACITY_REGISTRY && numOfWL <= MAX_CAPACITY_WAITLIST) {
            this.numSpace = numSpace;
            this.numOfWL = numOfWL;
        } else {
            this.numSpace = MAX_CAPACITY_REGISTRY;
            this.numOfWL = MAX_CAPACITY_WAITLIST;
        }

        registerList = new Student[numSpace];
        waitList = new Student[numOfWL];

        registeredShadow = new Student[numSpace];
        waitListShadow = new Student[numOfWL];



        addLimit = registerList.length + waitList.length;


    }

    //Overloaded constructor that only takes in the course name and sets the sizes of roster and waitlist
    //automatically by constants in the course class
    public Course(String course) {
        this(course, MAX_CAPACITY_REGISTRY, MAX_CAPACITY_WAITLIST);

    }

    //Our getters and Setters for our attributes for the Course class.
    public String getCourse() { return course; }
    public int getNumSpace() { return numSpace; }
    public int getNumOfWL() {return numOfWL; }

    public void setCourse(String course) {
        this.course = course;
    }

    public void setNumSpace(int numSpace) {

        if(numSpace <= MAX_CAPACITY_REGISTRY && numSpace > 0) {
            this.numSpace = numSpace;
        } else {
            this.numSpace = MAX_CAPACITY_REGISTRY;
        }

    }

    public void setNumOfWL(int numOfWL) {

        if(numOfWL <= MAX_CAPACITY_WAITLIST && numOfWL > 0) {
            this.numOfWL = numOfWL;
        } else {
            this.numOfWL = MAX_CAPACITY_WAITLIST;
        }

    }

    //My addStudent() that verifies if the add count is over 1 to check to see if any instance of the
    //student object trying to add is already in the roster or waitlist. Utilizes the equals() of the Student class.
    public boolean addStudent(Student student) {

        boolean isInRoster = false, isInWaitlist = false;

        if(addCounter >= 1) {

            for (int i = 0; i < registerList.length; i++) {
                if (registerList[i].equals(student)) {
                    isInRoster = true;
                }
            }

            for (int j = 0; j < waitList.length; j++) {
                if (waitList[j].equals(student)) {
                    isInWaitlist = true;
                }
            }
        }

        if(!(isInRoster && isInWaitlist)) {

            if (student.isTuitionPaid() == true && addCounter <= addLimit) {

                if (addCounter < registerList.length) {
                    registeredShadow[addCounter] = student;
                    registerList = registeredShadow;
                    addCounter++;
                } else if (addCounter >= registerList.length) {
                    try {
                        waitListShadow[addCounter - registerList.length] = student;
                        waitList = waitListShadow;
                        addCounter++;
                    } catch (ArrayIndexOutOfBoundsException e) {
                        System.out.println("\nCannot add " + student.toString() + "\n");
                        return false;
                    }
                }

                System.out.println("# of additions " + addCounter);

                return true;


            } else {
                System.out.println("Unable to add student: " + student.toString());
                return false;
            }

        } else {
            System.out.println("Unable to add student: " + student.toString());
            return false;
        }
    }


    //My dropStudent() that utilizes 2 other private methods that drop the student from wait list or the roster.
    public boolean dropStudent(Student student) {

        int position = 0;
        boolean inRoster = false, inWaitList = false;

        for (int i = 0; i < registerList.length; i++) {

            if (registerList[i].equals(student) == true) {
                inRoster = true;
                inTheRoster = inRoster;
                position = i;
            } else {
                for (int j = 0; j < waitList.length; j++) {

                    if (waitList[j].equals(student)) {
                        inWaitList = waitList[j].equals(student);
                        inTheWaitList = inWaitList;
                        position = j;
                    }
                }

            }

        }


        if (inRoster == true) {
            System.out.println("DropStudent in roster true");
            dropAndShiftRoster(position);
            return inRoster;
        }

        if (inWaitList == true) {
            dropAndShiftWaitList(position);
            System.out.println("DropStudent in Waitlist true");
            return inWaitList;
        }

        return false;



    }



    //method has been split into two different methods. Don't pay attention to this.
/*
    private void dropAndShift(int numPosition) {

        int swapIndex1 = 0;
        int swapIndex2 = 0;

        Student placeHold = new Student();

        if(inTheRoster == true) {
            registerList[numPosition] = placeHold;

            for(int i = numPosition; i < registerList.length - 1; i++) {
                registerList[i] = registerList[i + 1];

            }

            registerList[registerList.length -1] = waitList[0];

            for(int m = 0; m < waitList.length - 1; m++) {
                waitList[m] = waitList[m +1];
            }

            waitList[waitList.length - 1] = placeHold;

        } else if(inTheWaitList == true) {

            waitList[numPosition] = placeHold;

            for(int j = numPosition; j < waitList.length - 1; j++) {
                waitList[j] = waitList[j + 1];
            }

            waitList[waitList.length-1] = placeHold;
        }


    }

    */



    //Our drop method that drops students from the roster after checking the registerList array.
    private void dropAndShiftRoster(int numPosition) {
        Student placeHold = new Student();

        if (inTheRoster == true) {
            registerList[numPosition] = placeHold;

            for (int i = numPosition; i < registerList.length - 1; i++) {
                registerList[i] = registerList[i + 1];

            }

            registerList[registerList.length - 1] = waitList[0];

            for (int m = 0; m < waitList.length - 1; m++) {
                waitList[m] = waitList[m + 1];
            }

            waitList[waitList.length - 1] = placeHold;
        }


    }

    //Our drop method that drops students from the waitlist after checking the wait list array.
    private void dropAndShiftWaitList(int numPosition) {
        Student placeHold = new Student();

        if(inTheWaitList == true) {

            waitList[numPosition] = placeHold;

            for(int j = numPosition; j < waitList.length - 1; j++) {
                waitList[j] = waitList[j + 1];
            }

            waitList[waitList.length-1] = placeHold;
        }

    }




    @Override
    public String toString() {

        String stringRoster = "";
        String stringWaitList = "";

        for(int i = 0; i < registerList.length; i++) {
            if(registerList[i] == null){
                stringRoster += "empty" + "\n";
            } else {
                stringRoster += registeredShadow[i] + "\n";
            }
        }

        for(int j = 0; j < waitList.length; j++) {
            if(waitList[j] == null) {
                stringWaitList += "empty" + "\n";
            } else {
                stringWaitList += waitList[j] + "\n";
            }
        }

        String s = "Course: " + course + "\n"
                + "Max capacity of registry: " + numSpace + "\n"
                + "Max capacity of waitlist: " + numOfWL + "\n\n"
                + "Students Registered: \n" + stringRoster + "\n"
                + "Students Waitlisted: \n" + stringWaitList + "\n";

        return s;

    }




}
