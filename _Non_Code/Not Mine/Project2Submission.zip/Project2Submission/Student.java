public class Student {

    private String firstName, lastName, id;
    private boolean tuitionPaid;

    public Student(String firstName, String lastName, String id, boolean tuitionPaid) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
        this.tuitionPaid = tuitionPaid;
    }


    //Overloaded constructer primarily used as a place holder in the course waitlist.
    public Student() {
        this("N/A", "N/A", "N/A", true);
    }


    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }

    public boolean isTuitionPaid() {
        return tuitionPaid;
    }

    public void setTuitionPaid(boolean tuitionPaid) {
        this.tuitionPaid = tuitionPaid;
    }

    //Overriden equals() from the Object class. Checks to see if the Object in comparison
    //has the equivalent first and last name as well as the student ID and tuition status.
    //and returns a true value if all cases are true.
    @Override
    public boolean equals(Object obj) {

        boolean sameID, sameFirst, sameLast, tuitionStatus;


        if(obj instanceof Student) {

            Student person = (Student) obj;

            if(this.id.equalsIgnoreCase(person.id)) {
                sameID = true;
            } else {
                sameID = false;
            }

            if(this.firstName.equalsIgnoreCase(person.firstName) &&
                    this.lastName.equalsIgnoreCase(person.lastName)) {
                sameFirst = true;
                sameLast = true;
            } else {
                sameFirst = false;
                sameLast = false;

            }

            if(this.tuitionPaid == person.tuitionPaid) {
                tuitionStatus = true;
            } else {
                tuitionStatus = false;
            }

            return sameID && sameFirst && sameLast && tuitionStatus;

        } else {
            return false;
        }


    }

    @Override
    public String toString() {
        return firstName + " " + lastName + " (" + id + ")";
    }

}
