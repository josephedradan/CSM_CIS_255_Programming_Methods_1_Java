import java.util.Scanner;

public class CourseDriver {

    //Two scanner objects, one for obtaining string and the other integers from user. Just to avoid the
    //logic buffer using the Scanner class's nextLine().
    private static Scanner inputNum = new Scanner(System.in);
    private static Scanner inputString = new Scanner(System.in);

    public static void main(String[] args) {

        //Variables that store in user input, information about the class and initialization of our course object.
        Course classCourse;
        String courseName;
        int rosterSize, waitListSize;

        //Variables needed that store in the information about the student. Used to define student objects that will be
        //used in the the add and drop method.
        String firstName, lastName, id, tuition;
        boolean tuitionStatus;

        //Sentinal variables that causes our loop to finish.
        String exitCode = "quit";

        //Variables that we use to store info from the user.
        String usrInput = "";
        int optionNum;


        //Introduction to the program and prompts the user for the course name, size of roster and size of wait list.
        System.out.println("\nWelcome to the course registry program.\n" +
                           "Please input a course, set size of the roster\n" +
                           "and the wait list size. The maximum roster and wait list\n" +
                           "size is 30.\n");

        System.out.print("Course Name: ");
        courseName = inputString.nextLine();
        System.out.print("Roster Size: ");
        rosterSize = inputNum.nextInt();
        System.out.print("Wait List Size: ");
        waitListSize = inputNum.nextInt();

        //Declaration of out Object using a constructor.
        classCourse = new Course( courseName, rosterSize, waitListSize);

        System.out.println("\nWelcome to " + courseName + " students currently" +
                           " enrolled:\n" + classCourse.toString());


        //Our while loop that begins prompting user for input to add a student , drop a student, print the class
        //information or exit the program.
        while(!(usrInput.equalsIgnoreCase(exitCode))) {

            System.out.println("Choose from the following options:\n" +
                               "1 - Register student\n" +
                               "2 - Drop student\n" +
                               "3 - Print the course\n" +
                               "4 - To exit program");

            optionNum = inputNum.nextInt();

            //Switch case that handles the user input depending on the choice 1-4, default just exits the program.
            switch (optionNum) {

                case 1 /*add student*/ :
                    classCourse.addStudent(createStudent());
                    break;

                case 2 /*drop student*/ :
                    classCourse.dropStudent(createStudent());
                    break;

                case 3 /*print the course info*/:
                    System.out.println(classCourse.toString());
                    break;

                case 4 /*exits the program*/ :
                    usrInput = exitCode;
                    break;

                    default:
                        usrInput = exitCode;
                        break;

            }

        }

        System.out.println("Program has finished execution.");
        System.out.println("Programmed by John San Jose\n");



    }


    //Private static method of the driver that creates a student object every time it is called rather than
    //rewriting code just to create a student object whenever cases 1 and 2 are called.
    private static Student createStudent() {

        String firstName, lastName, id, tuition;
        boolean tuitionStatus;

        System.out.println("Enter first name: ");
        firstName = inputString.nextLine();

        System.out.println("Enter last name: ");
        lastName = inputString.nextLine();

        System.out.println("Enter ID: ");
        id = inputString.nextLine();

        System.out.println("Has the student payed the tuition fee? y/n");
        tuition = inputString.nextLine();

        if (tuition.equalsIgnoreCase("y")) {
            tuitionStatus = true;
        } else if (tuition.equalsIgnoreCase("n")) {
            tuitionStatus = false;
        } else {
            tuitionStatus = false;
        }

        Student student = new Student( firstName, lastName, id, tuitionStatus);

        return student;
    }
}
