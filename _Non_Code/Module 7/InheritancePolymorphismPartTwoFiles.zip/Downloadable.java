
public interface Downloadable {

	//int getFileSize();
	void download();
}
