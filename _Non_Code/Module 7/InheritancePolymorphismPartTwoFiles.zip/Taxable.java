
public interface Taxable {
	
	double TAX_RATE = 0.09; 
	
	double taxedPrice();

}
