
public interface Expirable {
	
	void checkExpirationStatus();

}
