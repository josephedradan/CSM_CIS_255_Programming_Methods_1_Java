
public class PersonalCareItem extends PersonalItem {
	
	private static final boolean RESTRICTED_STATUS = false;
	
	public PersonalCareItem(String name, String brand, double price) {
		super(name, brand, price, RESTRICTED_STATUS);
	}
	

}
