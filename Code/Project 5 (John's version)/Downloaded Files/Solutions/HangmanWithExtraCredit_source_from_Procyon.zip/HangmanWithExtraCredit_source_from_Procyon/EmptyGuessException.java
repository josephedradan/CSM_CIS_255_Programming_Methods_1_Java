// 
// Decompiled by Procyon v0.5.30
// 

public class EmptyGuessException extends Exception
{
    public EmptyGuessException() {
        super("Guesses cannot be empty.");
    }
}
