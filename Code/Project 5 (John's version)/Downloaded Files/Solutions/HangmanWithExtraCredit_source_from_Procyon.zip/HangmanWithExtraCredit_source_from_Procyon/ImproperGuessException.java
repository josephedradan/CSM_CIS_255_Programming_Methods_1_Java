// 
// Decompiled by Procyon v0.5.30
// 

public class ImproperGuessException extends Exception
{
    public ImproperGuessException() {
        super("Guesses must be characters only.");
    }
}
