// 
// Decompiled by Procyon v0.5.30
// 

public class GuessTooLongException extends Exception
{
    public GuessTooLongException() {
        super("Guesses must be one character only.");
    }
}
