
import java.math.BigDecimal;
import java.math.MathContext;

public class Circle extends TwoDimensional {

    private int radius;
    private final int SMALLEST_VALUE = 1;

    public Circle(int radius) {

        if(radius > 0) {
            this.radius = radius;
        } else {
            this.radius = SMALLEST_VALUE;
        }

    }

    public int getRadius() { return radius; }

    public void setRadius(int radius) {
        if (radius > 0) {
            this.radius = radius;
        } else {
            System.out.println("Improper entry for radius.\n");
        }
    }

    @Override
    public double calculateArea() {
        return Math.PI * Math.pow(getRadius(), 2);
    }

    @Override
    public double calculatePerimeter() {
        return 2 * Math.PI * getRadius();
    }



    /*
    @Override
    public String toString() {

        BigDecimal area = new BigDecimal(this.calculateArea());
        BigDecimal perimeter = new BigDecimal(this.calculatePerimeter());

        area = area.round( new MathContext(3));
        perimeter = perimeter.round(new MathContext(3));

        String s = "This shape is a " + this.getDescription() + " and it has a radius of " + this.getRadius() +
                " it has an area of " + area + "\nand has a perimeter of " + perimeter;

        return s;
    }*/


}
