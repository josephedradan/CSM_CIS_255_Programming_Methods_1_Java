public class Square extends Rectangle {

    private final int DEFAULT_SIZE = 1;

    //Constructor also sets the object with length and width only and auto selects the description
    //and the radius because it is a square. However a default size is set in place if usr inputs incorrect values.
    //it does this by calling set methods found in the.
    public Square(int length, int width) {
        super(length, width);

        if(this.getLength() == this.getWidth()) {
            setLength(length);
            setWidth(width);
        } else {
            setLength(DEFAULT_SIZE);
            setWidth(DEFAULT_SIZE);
        }
    }



/*
    @Override
    public String toString() {
        String s = "This shape is a " + this.getDescription() + " and it has a length of " +
                this.getLength() + " and a width of " + this.getWidth() + ".\n" + "it has an area of " +
                this.calculateArea() + " and has a perimeter of " + this.calculatePerimeter();

        return s;
    }

*/

}
