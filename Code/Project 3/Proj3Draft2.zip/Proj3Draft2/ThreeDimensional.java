public abstract class ThreeDimensional extends Shape {

    //Suggetion to add another instance variable "height" because it has not been included in the Shapes abstract class
    //BC all shapes in general have a length and a width but not all shapes have a value for height.
    //Getters and Setters would also be needed too! GOOD LUCK JOSEPH :D. HMU if you need anything. Seriously LOL like
    //call or something.

    @Override
    public abstract double calculateArea();
}
