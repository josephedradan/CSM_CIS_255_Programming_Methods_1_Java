public class Test {

    public static void main(String[] args) {

        Rectangle test1 = new Rectangle(2, 3);
        Rectangle test2 = new Rectangle(3, 2);
        Square test3 = new Square(2, 2);
        Square test4 = new Square(3, 1);
        Circle test5 = new Circle(3);
        Circle test6 = new Circle(3);
        Circle test7 = new Circle(5);


        /*
        boolean stat = test1.equals(test2);

        System.out.println(test4.getLength() + "x" + test4.getWidth());

        System.out.println(test1.getDescription());

        System.out.println(stat);

        System.out.println();

        System.out.println(test5.calculateArea());
        System.out.println(test5.calculatePerimeter());

        System.out.println(test1.toString());

        System.out.println(test5.toString());
        */
    }
}
