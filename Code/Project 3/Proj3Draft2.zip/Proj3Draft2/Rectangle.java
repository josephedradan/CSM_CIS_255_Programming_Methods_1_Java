public class Rectangle extends TwoDimensional {


    private int length, width;
    private final int SMALLEST_VALUE = 1;


    public Rectangle(int length, int width) {
        if(length > 0 && width > 0) {

            this.length = length;
            this.width = width;

        } else {

            this.length = SMALLEST_VALUE;
            this.width = SMALLEST_VALUE;

        }
    }


    //Getters and Setters
    public int getLength() { return length; }
    public int getWidth() { return width; }

    public void setLength(int length) {

        if (length > 0) {
            this.length = length;
        } else {
            System.out.println("Improper entry for length.\n");
        }

    }

    public void setWidth(int width) {

        if (width > 0) {
            this.width = width;
        } else {
            System.out.println("Improper entry for width.\n");
        }

    }


    @Override
    public double calculateArea() {
        return getLength() * getWidth();
    }

    @Override
    public double calculatePerimeter() {
        return 2 * getLength() + 2 * getWidth();
    }


    //Constructor that only takes 2 values, auto selects radius to be 0 since its a rectangle.
    // and automatically sets the description.
    /*public Rectangle(int length, int width) {
        super(length, width, 0, "Rectangle");
    }*/


    /*
    @Override
    public String toString() {
        String s = "This shape is a " + this.getDescription() + " and it has a length of " +
                this.getLength() + " and a width of " + this.getWidth() + ".\n" + "it has an area of " +
                this.calculateArea() + " and has a perimeter of " + this.calculatePerimeter();

        return s;
    }*/


}
