public abstract class TwoDimensional extends Shape {

    /*
    public TwoDimensional(int length, int width, int radius, String description) {
        super(length, width, radius, description);
    }*/
    /*
    @Override
    public boolean equals(Object obj) {
        //placeholder
        boolean sameLength, sameWidth, sameRadius;

        //if the object is a Rectangle or Square and it has the same Length and Width
        //then its considered to be the same. Else if the object in comparison is a circle
        //then it only compares its radius. Otherwise if its not the neither a square, rectangle, or circle
        //this method returns false.
        if(obj instanceof Square || obj instanceof Rectangle) {
            Rectangle quad = (Rectangle) obj;

            if(quad.getLength() == this.getLength()) {
                sameLength = true;
            } else {
                sameLength = false;
            }

            if(quad.getWidth() == this.getWidth()) {
                sameWidth = true;
            } else {
                sameWidth = false;
            }

            if(quad.getWidth() == this.getLength() &&
               quad.getLength() == this.getWidth()) {
                sameLength = true;
                sameWidth = true;
            } else {
                sameLength = false;

                    sameWidth = false;
                    }

                    return sameLength && sameWidth;

                    } else if(obj instanceof Circle) {
                    Circle coin = (Circle) obj;

                    if(coin.getRadius() == this.getRadius()) {
                    sameRadius = true;
                    } else {
                    sameRadius = false;
                    }

                    return sameRadius;

                    } else {
                    return false;
                    }
                    }*/

    //All 2D shapes can only calculate for area and perimeter only so 2 abstract methods are needed
    //for all 2D shapes.
    @Override
    public abstract double calculateArea();
    public abstract double calculatePerimeter();

}
