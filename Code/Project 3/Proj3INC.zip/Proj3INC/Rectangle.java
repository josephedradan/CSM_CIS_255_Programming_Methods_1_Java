public class Rectangle extends TwoDimensional {


    //Constructor that only takes 2 values, auto selects radius to be 0 since its a rectangle.
    // and automatically sets the description.
    public Rectangle(int length, int width) {
        super(length, width, 0, "Rectangle");
    }

    @Override
    public double calculateArea() {
        return getLength() * getWidth();
    }

    @Override
    public double calculatePerimeter() {
        return 2 * getLength() + 2 * getWidth();
    }

    @Override
    public String toString() {
        String s = "This shape is a " + this.getDescription() + " and it has a length of " +
                this.getLength() + " and a width of " + this.getWidth() + ".\n" + "it has an area of " +
                this.calculateArea() + " and has a perimeter of " + this.calculatePerimeter();

        return s;
    }


}
