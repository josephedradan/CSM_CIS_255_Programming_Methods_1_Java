public abstract class Shapes {

    //Different attributes that any shape has.
    //Can have  (length and width) or a radius.

    private int length, width, radius;
    private String description;

    //Two different constructors to allow us more flexibility on how we declare in source code.
    public Shapes(int length, int width, int radius, String description) {

        //If theres a length and width given shape obviously won't be
        //circular or spherical.
        if(length > 0 && width > 0) {

            this.length = length;
            this.width = width;
            this.radius = 0;
        } else {

            this.length = 0;
            this.width = 0;
            this.radius = radius;

        }

        this.description = description;

    }

    public Shapes(int length, int width, int radius) {
        this(length, width, radius, null);
    }

    //Our getters for our dimensions.
    public int getLength() { return length; }
    public int getWidth() { return width; }
    public int getRadius() { return radius; }
    public String getDescription() { return description; }


    //Our setters for our dimensions that do not allow a negative value.
    public void setLength(int length) {

        if (length > 0) {
            this.length = length;
        } else {
            System.out.println("Improper entry for length.\n");
        }

    }

    public void setWidth(int width) {

        if (width > 0) {
            this.width = width;
        } else {
            System.out.println("Improper entry for width.\n");
        }

    }

    public void setRadius(int radius) {
        if (radius > 0) {
            this.radius = radius;
        } else {
            System.out.println("Improper entry for radius.\n");
        }
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public abstract double calculateArea();

}
