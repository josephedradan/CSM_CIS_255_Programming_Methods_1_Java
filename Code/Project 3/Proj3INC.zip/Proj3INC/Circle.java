
import java.math.BigDecimal;
import java.math.MathContext;
import java.util.*;

public class Circle extends TwoDimensional {

    public Circle(int radius) {
        super(0, 0 , radius, "Circle");
    }

    @Override
    public double calculateArea() {
        return Math.PI * Math.pow(getRadius(), 2);
    }

    @Override
    public double calculatePerimeter() {
        return 2 * Math.PI * getRadius();
    }

    @Override
    public String toString() {

        BigDecimal area = new BigDecimal(this.calculateArea());
        BigDecimal perimeter = new BigDecimal(this.calculatePerimeter());

        area = area.round( new MathContext(3));
        perimeter = perimeter.round(new MathContext(3));

        String s = "This shape is a " + this.getDescription() + " and it has a radius of " + this.getRadius() +
                " it has an area of " + area + "\nand has a perimeter of " + perimeter;

        return s;
    }


}
