//Not all animals have wings and this interface applies to some certain mammals and
//birds.
public interface Winged {

    boolean flies();
}
