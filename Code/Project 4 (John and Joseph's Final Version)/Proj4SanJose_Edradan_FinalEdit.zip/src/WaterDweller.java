//Some animals that dwell on water can also live on land, associated more
//with mammals and fish.
public interface WaterDweller {

    boolean livesOnLand();
}
