//Set Adoptable as an interface because not all animals are adoptable but there are
//certain animals that can be and they come from different classes in the animal kingdom.

public interface Adoptable {

    public String getHomeCareInstructions();
}
